const bookingForm = document.getElementById("booking-form");

bookingForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("email");
    const content = document.getElementById("content");
    const book_meeting = document.getElementById("book_meeting");
    const booking_DT = document.getElementById("booking_DT");

    fetch("/createNewContact", {
        method: "POST",
        headers: {
            "content-type": "application/json",
        },
        body: JSON.stringify({
            email: email.value,
            content: content.value,
            book_meeting: book_meeting.value,
            booking_DT: getFormattedDateTime(booking_DT.value),
        }),
    })
        .then((res) => res.json())
        .then((res) => {
            if (res) {
                alert("The booking request was added successfully");
                window.location = "homePage";
            } else if (res.err) {
                console.log(res);
                alert(res.err);
            }
        });
});
