const trainingsElem = document.getElementById("trainings");

fetch(`/getMyTrainings`, {
    method: "GET",
    headers: {
        "Content-Type": "application/json",
    },
})
    .then((res) => res.json())
    .then((res) => {
        if (res.length > 0) {
            let html = `
                <table>
                    <tr>
                        <th>Type</th>
                        <th>Date</th>
                        <th></th>
                    </tr>
            `;
            for (let i = 0; i < res.length; i++) {
                const training = res[i];
                html += `
                    <tr>
                        <td>${training.type}</td>
                        <td>${toDateTime(training.date)}</td>
                        <td>
                        <button onclick="editTraining(${
                            training.id
                        })">Edit</button>
                            <button onclick="deleteTraining(${
                                training.id
                            })">Delete</button>
                        </td>
                    </tr>
                `;
            }
            html += "</table>";
            trainingsElem.innerHTML += html;
        } else {
            trainingsElem.innerHTML += `<p>No trainings were found</p>`;
        }
    });

function deleteTraining(id) {
    if (confirm("Do you sure you'd like to delete this training?")) {
        fetch(`/deleteTraining?id=${id}`, {
            method: "DELETE",
            headers: {
                "content-type": "application/json",
            },
        })
            .then((res) => res.json())
            .then((res) => {
                if (res) {
                    alert("Training deleted successfully");
                    window.location.reload();
                } else if (res.err) {
                    console.log(res);
                    alert(res.err);
                }
            });
    }
}

function editTraining(id) {
    window.location = `editTraining?id=${id}`;
}
