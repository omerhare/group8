const loggedInUserCookie = getCookie("loggedInUser");
if (loggedInUserCookie) {
    const loggedInUser = JSON.parse(loggedInUserCookie.slice(2));
    document.body.innerHTML =
        `
    <header>
        <nav>
            <img class="logo" src="/images/logo.png" , alt="LOGO" />
            <ul>
                <li><a href="homePage">Home</a></li>
                <li><a href="myTrainings">My Trainings</a></li>
                <li><a href="contactUs">Contact Us</a></li>
                <li><a href="doLogout">Logout</a></li>
            </ul>
        </nav>
    </header>
` + document.body.innerHTML;
} else {
    document.body.innerHTML =
        `
    <header>
        <nav>
            <img class="logo" src="/images/logo.png" , alt="LOGO" />
            <ul>
                <li><a href="login">Login</a></li>
                <li><a href="signup">Sign up</a></li>
                <li><a href="contactUs">Contact Us</a></li>
            </ul>
        </nav>
    </header>
` + document.body.innerHTML;
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function toDateTime(date) {
    if (!date) {
        return "";
    }

    var d = new Date(date);
    return `${("00" + d.getDate()).slice(-2)}/${(
        "00" +
        (d.getMonth() + 1)
    ).slice(-2)}/${d.getFullYear()} ${("00" + d.getHours()).slice(-2)}:${(
        "00" + d.getMinutes()
    ).slice(-2)}`;
}

function getFormattedDateTime(date) {
    if (!date) {
        return "";
    }

    var d = new Date(date);
    return `${d.getFullYear()}-${("00" + (d.getMonth() + 1)).slice(-2)}-${(
        "00" + d.getDate()
    ).slice(-2)} ${("00" + d.getHours()).slice(-2)}:${(
        "00" + d.getMinutes()
    ).slice(-2)}`;
}

function getQueryParam(key) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(key);
}
