const typeSelectElem = document.getElementById("type");
const id = getQueryParam("id");
document.getElementById("id").value = id;

const type = document.getElementById("type");
const date = document.getElementById("date");

fetch(`/getTrainingTypes`, {
    method: "GET",
    headers: {
        "Content-Type": "application/json",
    },
})
    .then((res) => res.json())
    .then((res) => {
        if (res.length > 0) {
            for (let i = 0; i < res.length; i++) {
                const type = res[i];
                typeSelectElem.innerHTML += `<option value="${type.id}">${type.type}</option>`;
            }

            fetch(`/getTrainingById?id=${id}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                },
            })
                .then((res) => res.json())
                .then((res) => {
                    setTimeout(() => {
                        type.value = res.trainingId;
                        date.value = getFormattedDateTime(res.date);
                    }, 0);
                });
        }
    });

const editTraining = (e) => {
    e.preventDefault();

    if (!type.value || !date.value) {
        alert("All fields are required!");
        return false;
    }

    fetch("/editTraining", {
        method: "PUT",
        headers: {
            "content-type": "application/json",
        },
        body: JSON.stringify({
            id,
            type: type.value,
            date: getFormattedDateTime(date.value),
        }),
    })
        .then((res) => res.json())
        .then((res) => {
            if (res) {
                alert("The training was updated successfully");
                window.location = "myTrainings";
            } else if (res.err) {
                console.log(res);
                alert(res.err);
            }
        });
};

const form = document.forms[0];
if (form) {
    form.addEventListener("submit", editTraining);
}
