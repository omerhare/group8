const typeSelectElem = document.getElementById("type");

fetch(`/getTrainingTypes`, {
    method: "GET",
    headers: {
        "Content-Type": "application/json",
    },
})
    .then((res) => res.json())
    .then((res) => {
        if (res.length > 0) {
            for (let i = 0; i < res.length; i++) {
                const type = res[i];
                typeSelectElem.innerHTML += `<option value="${type.id}">${type.type}</option>`;
            }
        }
    });

const createTraining = (e) => {
    e.preventDefault();

    const type = document.getElementById("type");
    const date = document.getElementById("date");

    if (!type.value || !date.value) {
        alert("All fields are required!");
        return false;
    }

    fetch("/createTraining", {
        method: "POST",
        headers: {
            "content-type": "application/json",
        },
        body: JSON.stringify({
            type: type.value,
            date: getFormattedDateTime(date.value),
        }),
    })
        .then((res) => res.json())
        .then((res) => {
            if (res) {
                alert("The training was added successfully");
                window.location = "myTrainings";
            } else if (res.err) {
                console.log(res);
                alert(res.err);
            }
        });
};

const form = document.forms[0];
if (form) {
    form.addEventListener("submit", createTraining);
}
