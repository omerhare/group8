const express = require("express");
const app = express();
const path = require("path");
const BodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const initDB = require("./db/initDB");
const CRUD = require("./db/crud");

app.use(cookieParser());
app.use(BodyParser.json());
app.use(BodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "views")));
app.use(express.static(path.join(__dirname, "static")));
app.use(express.static(path.join(__dirname, "public")));
app.use("/images", express.static(path.join(__dirname, "public/images")));
app.use("/js", express.static(path.join(__dirname, "public/js")));

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

// Define APIS
app.get("/createDB", (req, res) => {
    initDB.createDb(req, res);
});
app.get("/dropDB", (req, res) => {
    initDB.dropDb(req, res);
});

// Define routes
app.get("/signup", (req, res) => {
    res.render("signup");
});

app.get("/login", (req, res) => {
    res.render("login");
});

app.get("/contactUs", (req, res) => {
    res.render("contactUs");
});

app.get("/", (req, res) => {
    if (req.cookies.loggedInUser) {
        res.render("homePage");
    }
    res.render("login");
});

app.get("/homePage", (req, res) => {
    if (req.cookies.loggedInUser) {
        res.render("homePage");
    }
    res.render("login");
});

app.get("/myTrainings", (req, res) => {
    if (req.cookies.loggedInUser) {
        res.render("myTrainings");
    }
    res.render("login");
});

app.get("/editTraining", (req, res) => {
    if (req.cookies.loggedInUser) {
        res.render("editTraining");
    }
    res.render("login");
});

app.get("/newTraining", (req, res) => {
    if (req.cookies.loggedInUser) {
        res.render("newTraining");
    }
    res.render("login");
});

// Endpoints
app.post("/doLogin", CRUD.login);
app.get("/doLogout", CRUD.logout);
app.post("/doSignup", CRUD.signup);
app.post("/createNewContact", CRUD.createNewContact);
app.get("/getMyTrainings", CRUD.myTrainings);
app.get("/getTrainingById", CRUD.getTrainingById);
app.get("/getTrainingTypes", CRUD.getTrainingTypes);
app.delete("/deleteTraining", CRUD.deleteTraining);
app.post("/createTraining", CRUD.createTraining);
app.put("/editTraining", CRUD.editTraining);

// Start the server
app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});
