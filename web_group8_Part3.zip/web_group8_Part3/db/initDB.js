const sql = require("./db");
const path = require("path");
const csv = require("csvtojson");

const createDb = (req, res) => {
    const query = `CREATE DATABASE IF NOT EXISTS web`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("created db web");

        createTableUsers(req, res);
        createTableContacts(req, res);
        createTableTrainings(req, res);
        createTableTrainedAt(req, res);

        insertTableUsers(req, res);
        insertTableTrainigs(req, res);
        setTimeout(() => {
            insertTableTrainedAt(req, res);
            res.send("DB was created successfully");
        }, 300);
    });
};

const dropDb = (req, res) => {
    const query = `DROP DATABASE IF EXISTS web`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("dropped db web");
        res.send("DB was dropped successfully");
        return;
    });
};

const createTableUsers = (req, res) => {
    const query = `CREATE TABLE web.USERS (
        id INT NOT NULL AUTO_INCREMENT,
        username varchar(10),
        name_first varchar(255),
        name_last varchar(255),
        Date date,
        password varchar(20),
        gender ENUM('Male', 'Female', 'Other'),
        weight int,
        height int,
        workout_habits VARCHAR(255),
        fitness_goal varchar(100),
        preferred_activity VARCHAR(255),
        time_commitment VARCHAR(255),
        dietary_restrictions VARCHAR(255),
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table users");
        return;
    });
};

const createTableTrainings = (req, res) => {
    const query = `CREATE TABLE web.TRAININGS (
        id INT NOT NULL AUTO_INCREMENT,
        type varchar(25),
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table trainings");
        return;
    });
};

const createTableTrainedAt = (req, res) => {
    const query = `CREATE TABLE web.TRAINED_AT (
        id INT NOT NULL AUTO_INCREMENT,
        trainingId INT NOT NULL,
        userId INT NOT NULL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
        PRIMARY KEY (id)
    );`;
    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table trained_at");
        return;
    });
};

const createTableContacts = (req, res) => {
    const query = `CREATE TABLE web.CONTACTS (
        id INT NOT NULL AUTO_INCREMENT,
        email varchar(50),
        content TEXT,
        book_meeting varchar(3),
        booking_DT datetime,
        PRIMARY KEY (id)
    );`;

    sql.query(query, (error, mysqlres) => {
        if (error) {
            console.log(error);
            return;
        }
        console.log("create table contacts");
        return;
    });
};

const insertTableUsers = (req, res) => {
    const csvPath = path.join(__dirname, "./csv/USERS.csv");
    csv()
        .fromFile(csvPath)
        .then((jsonObj) => {
            jsonObj.forEach((element) => {
                console.log(element);
                const newRecord = {
                    id: element.id,
                    username: element.username,
                    name_first: element["name-first"],
                    name_last: element["name-Last"],
                    Date: element.Date,
                    password: element.password,
                    gender: element.gender,
                    weight: element.weight,
                    height: element.height,
                    workout_habits: element.workout_habits,
                    fitness_goal: element.fitness_goal,
                    preferred_activity: element.preferred_activity,
                    time_commitment: element.time_commitment,
                    dietary_restrictions: element.dietry_restrictions,
                };
                const query = `INSERT INTO web.USERS SET ?`;
                sql.query(query, newRecord, (err, mysqlres) => {
                    if (err) {
                        throw err;
                    } else {
                        console.log("created user record successfully");
                    }
                });
            });
            console.log("all user records was created successfully");
        });
};

const insertTableTrainigs = (req, res) => {
    const csvPath = path.join(__dirname, "./csv/TRAININGS.csv");
    csv()
        .fromFile(csvPath)
        .then((jsonObj) => {
            jsonObj.forEach((element) => {
                console.log(element);
                const newRecord = {
                    id: element.id,
                    type: element.type,
                };
                const query = `INSERT INTO web.TRAININGS SET ?`;
                sql.query(query, newRecord, (err, mysqlres) => {
                    if (err) {
                        throw err;
                    } else {
                        console.log("created training record successfully");
                    }
                });
            });
            console.log("all training records was created successfully");
        });
};

const insertTableTrainedAt = (req, res) => {
    sql.query("SELECT * FROM web.USERS", (err, results) => {
        if (err) {
            console.log("Error: " + err);
            res.status(400).send({
                message: "Error in finding users: " + err,
            });
            return;
        }
        console.log(results);
        for (let i = 0; i < results.length; i++) {
            const newRecord = {
                userId: results[i].id,
                trainingId: i + 1,
            };
            const query = `INSERT INTO web.TRAINED_AT SET ?`;
            sql.query(query, newRecord, (err, mysqlres) => {
                if (err) {
                    throw err;
                } else {
                    console.log("created training record successfully");
                }
            });
        }
    });
};

module.exports = {
    createDb,
    dropDb,
};
