module.exports = {
    HOST: "", // we don't write a name
    USER: "root",
    PASSWORD: "Omer3489@",
    DB: "web" // מה שרשום ב MYSQL
};
