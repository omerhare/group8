const sql = require("./db");

const login = (req, res) => {
    // check if body is empty
    if (!req.body) {
        res.status(400).send({ err: "Content can not be empty" });
        return;
    }
    // if body not empty - find customer by name
    const username = req.body.username; // Assuming the username is sent in the request body
    const password = req.body.password; // Assuming the password is sent in the request body

    // Insert query
    sql.query(
        "SELECT * FROM web.users WHERE username LIKE ? AND password = ? LIMIT 1",
        [username, password],
        (err, results) => {
            if (err) {
                console.log("Error: " + err);
                res.status(400).send({
                    err: "Error in finding customer: " + err,
                });
                return;
            }

            // If no query error
            console.log("Results: ", results);
            console.log(username);
            if (results.length > 0) {
                const loggedInUser = results[0];
                res.cookie("loggedInUser", loggedInUser);
                res.redirect("/homePage");
            } else {
                // Redirect to signup
                res.redirect("/signup"); // need to change
            }
        }
    );
};

const logout = function (req, res) {
    res.clearCookie("loggedInUser");
    res.redirect("/login");
};

const signup = function (req, res) {
    // Validate request
    if (!req.body) {
        res.status(400).send({ err: "Content can not be empty!" });
        return;
    }

    const newCustomer = {
        username: req.body.username,
        name_first: req.body.name_first,
        name_last: req.body.name_last,
        date: req.body.Date,
        password: req.body.password,
        gender: req.body.gender,
        weight: req.body.weight,
        height: req.body.height,
        workout_habits: req.body.workout_habits,
        fitness_goal: req.body.fitness_goal,
        preferred_activity: req.body.preferred_activity,
        time_commitment: req.body.time_commitment,
        dietary_restrictions: req.body.dietary_restrictions,
    };

    sql.query("INSERT INTO web.users SET ?", newCustomer, (err, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({
                err: "Error in creating customer: " + err,
            });
            return;
        }

        console.log("Created customer: ", {
            id: mysqlres.insertId,
            ...newCustomer,
        });
    });
};

const createNewContact = function (req, res) {
    // Validate request
    if (!req.body) {
        res.status(400).send({ err: "Content can not be empty!" });
        return;
    }

    const newContact = {
        email: req.body.email,
        content: req.body.content,
        book_meeting: req.body.book_meeting,
        booking_DT: req.body.booking_DT,
    };

    sql.query("INSERT INTO web.contacts SET ?", newContact, (err, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({
                err: "Error in creating customer: " + err,
            });
            return;
        }

        console.log("Created contact: ", {
            id: mysqlres.insertId,
            ...newContact,
        });

        res.status(200).json({});
    });
};

const myTrainings = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    }

    const q = `SELECT t.type, ta.* 
        FROM web.TRAINED_AT as ta 
        JOIN web.TRAININGS as t ON t.id = ta.trainingId 
        WHERE ta.userId = ${req.cookies.loggedInUser.id}`;

    sql.query(q, (err, data, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        } else if (!data?.length) {
            res.status(400).send({
                err: "No trainings were found for the user",
            });
        } else {
            res.status(200).json(data);
        }
    });
};

const getTrainingById = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    } else if (!req.query.id) {
        res.status(400).send({
            err: "training id is required!",
        });
    }

    const q = `SELECT * FROM web.TRAINED_AT WHERE id = ${req.query.id}`;

    sql.query(q, (err, data, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        } else if (!data?.length) {
            console.log("no training was found for the given id");
            res.status(400).send({
                err: "no training was found for the given id",
            });
        }
        res.status(200).json(data[0]);
    });
};

const getTrainingTypes = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    }

    const q = `SELECT DISTINCT(type), id FROM web.TRAININGS`;

    sql.query(q, (err, data, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        } else if (!data?.length) {
            res.status(400).send({
                err: "No types were found",
            });
        } else {
            res.status(200).json(data);
        }
    });
};

const deleteTraining = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    } else if (!req.query.id) {
        res.status(400).send({
            err: "training id is required!",
        });
    }

    const q = `DELETE FROM web.TRAINED_AT WHERE id = ${req.query.id}`;

    sql.query(q, (err, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        }
        res.status(200).json({});
    });
};

const createTraining = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    } else if (!req.body) {
        res.status(400).send({
            err: "body is missing!",
        });
    }

    const q = `INSERT INTO web.TRAINED_AT set ?`;
    const trainedAt = {
        trainingId: req.body.type,
        userId: req.cookies.loggedInUser.id,
        date: req.body.date,
    };

    sql.query(q, trainedAt, (err, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        }
        trainedAt.id = mysqlres.insertId;
        res.status(200).json(trainedAt);
    });
};

const editTraining = function (req, res) {
    if (!req.cookies.loggedInUser) {
        res.status(400).send({
            err: "Please login",
        });
    } else if (!req.body) {
        res.status(400).send({
            err: "body is missing!",
        });
    }

    const q = `UPDATE web.TRAINED_AT set ? WHERE id = ${req.body.id}`;
    const trainedAt = {
        trainingId: req.body.type,
        userId: req.cookies.loggedInUser.id,
        date: req.body.date,
    };

    sql.query(q, trainedAt, (err, mysqlres) => {
        if (err) {
            console.log("Error: ", err);
            res.status(400).send({ err });
            return;
        }
        trainedAt.id = mysqlres.insertId;
        res.status(200).json(trainedAt);
    });
};

module.exports = {
    login,
    logout,
    signup,
    createNewContact,
    myTrainings,
    getTrainingById,
    getTrainingTypes,
    deleteTraining,
    createTraining,
    editTraining,
};
